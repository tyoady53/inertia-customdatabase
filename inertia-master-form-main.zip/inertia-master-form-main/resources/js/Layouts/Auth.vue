<template>
    <div class="c-app flex-row align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <slot />
            </div>
        </div>
    </div>
</template>

<script>
    export default {

    }
</script>

<style>

</style>